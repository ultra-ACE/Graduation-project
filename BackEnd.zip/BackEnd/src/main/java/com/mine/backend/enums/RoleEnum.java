package com.mine.backend.enums;

public enum RoleEnum {
    Admin,
    User
}
